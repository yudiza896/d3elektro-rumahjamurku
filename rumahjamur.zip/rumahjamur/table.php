<table class="list" id="pengunjung">
		  <thead>
				<th class="table-header" width="10px">No.</th>
				<th class="table-header">Waktu</th>
				<th class="table-header">Suhu</th>
				<th class="table-header">Kelembaban</th>
		  </thead>
		<?php
			include_once "koneksi.php";
			$sql = "SELECT *FROM data ORDER BY id DESC LIMIT 10";
			$ambil=mysqli_query($koneksi, $sql);
			if ($ambil->num_rows > 0) {
				$k=1;
				while($row=mysqli_fetch_array($ambil))
				{?>
				<tr class="table-row">
					<td><?php echo $k++; ?></td>
					<td><?php echo $row["waktu"]; ?></td>
					<td><?php echo $row["suhu"]; ?></td>
					<td><?php echo $row["kelembaban"]; ?></td>
				 </tr>
				  <?php
				}
			}?>
			</table>