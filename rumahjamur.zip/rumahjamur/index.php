<html>
<head>
 <link rel="stylesheet" type="text/css" href="css/table.css">
 <link rel="stylesheet" type="text/css" href="css/style.css">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
 <script src="https://code.highcharts.com/highcharts.js"></script>
 <script src="https://code.highcharts.com/highcharts-more.js"></script>
 <script src="https://code.highcharts.com/modules/solid-gauge.js"></script>


<script>
  $(document).ready(function(){


setInterval(
  function() 
  {
  	$( "#pengunjung" ).load( "table.php #pengunjung" );
  	 //alert("hehe");

  $.ajax({
    url: 'data.php', // returns "[1,2,3,4,5,6]"
    dataType: 'json', // jQuery will parse the response as JSON
    success: function (outputfromserver) {

    //alert(outputfromserver);

    $.each(outputfromserver, function(index, el) {
        //alert("element at " + index + ": " + el); 
      if (index==0){
        $("#Suhu").html("<h1><b>"+el+"&#8451;</b></h1>");
      }
      if (index==1){
        $("#Kelembaban").html("<h1><b>"+el+"%</b></h1>");
      }
    });
}
});
  }, 1000);

$("#setSuhu").submit(function(event){
    event.preventDefault(); //prevent default action 
    var post_url = "download.php";
    var request_method = "GET";
    var form_data = $(this).serialize();

    $.ajax({
        url : post_url,
        type: request_method,
        data : form_data
    }).done(function(response){ //
        //alert(response);
    });
});

$("#setKelembaban").submit(function(event){
    event.preventDefault(); //prevent default action 
    var post_url = "download.php";
    var request_method = "GET";
    var form_data = $(this).serialize();

    $.ajax({
        url : post_url,
        type: request_method,
        data : form_data
    }).done(function(response){ //
        alert(response);
    });
});

});
</script>
</head>
<body>
<div class="judulUtama"><h1>Monitoring Suhu dan Kelembaban Rumah Jamur</h1></div>
<div class="judul">
<?php $tanggal=date("Y/m/d");

$day = date('D', strtotime($tanggal));
$dayList = array(
    'Sun' => 'Minggu',
    'Mon' => 'Senin',
    'Tue' => 'Selasa',
    'Wed' => 'Rabu',
    'Thu' => 'Kamis',
    'Fri' => 'Jumat',
    'Sat' => 'Sabtu'
); ?>

Hari ini : <?php echo $dayList[$day].", ".date("d/m/Y");
 ?></div>
 <div class="container-tengah">
<div class="card-judul">
    <div id="judulSuhu"><h3><b>Suhu</b></h3></div>
</div>
<div class="card-judul">
    <div id="judulKelembaban"><h3><b>Kelembaban</b></h3></div>
</div>
</div>
 <div class="container-tengah">
<div class="card">
    <div id="Suhu"><h1><b>20&#8451;</b></h1></div>
</div>
<div class="card">
    <div id="Kelembaban"><h1><b>20%</b></h1></div>
</div>
</div>

 <div class="container-tengah">
<div class="card">
    <div id="setSuhuu">
    <form action="download.php" id="setSuhu">
  <input type="text" name="settingSuhu" value="20"><br>
  <input class="myButton" id="setSuhunya" type="submit" value="Set">
</form></div>
</div>
<div class="card">
    <div id="setKelembabann">
    <form action="download.php" id="setKelembaban">
  <input type="text" name="settingKelembaban" value="70"><br>
  <input class="myButton" id="setKelembabannya" type="submit" value="Set">
</form></div>
</div>
</div>



<br><div class="judulUtama"><h3>Riwayat 10 Data Terakhir :</h3></div>
<div class="utama">
		<table class="list" id="pengunjung">
		  <thead>
				<th class="table-header" width="10px">No.</th>
				<th class="table-header">Waktu</th>
				<th class="table-header">Suhu</th>
				<th class="table-header">Kelembaban</th>
		  </thead>
		<?php
			include_once "koneksi.php";
			$sql = "SELECT *FROM data ORDER BY id DESC LIMIT 10";
			$ambil=mysqli_query($koneksi, $sql);
			if ($ambil->num_rows > 0) {
				$k=1;
				while($row=mysqli_fetch_array($ambil))
				{?>
				<tr class="table-row">
					<td><?php echo $k++; ?></td>
					<td><?php echo $row["waktu"]; ?></td>
					<td><?php echo $row["suhu"]; ?></td>
					<td><?php echo $row["kelembaban"]; ?></td>
				 </tr>
				  <?php
				}
			}?>
			</table></div>

      <div class="card-panjang">Oleh : <br>sdfsdf<br>dgsdgfsdg<br>Vokasi Teknik Elektro</div>
</body>
</html>