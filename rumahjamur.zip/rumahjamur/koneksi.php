<?php
$dbuser = 'u8658213_jamur';
$dbname = 'u8658213_rumahjamur';
$dbpassword = 'u8658213';
$dbhost = 'localhost';

///membuat koneksi
$koneksi = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname);

//mengecek koneksi
if ($koneksi->connect_error) {
	die("Koneksi gagal: ". mysqli_connect_error());
	}
//echo "Tersambung";
//mysql_select_db($dbname, $koneksi);
?>