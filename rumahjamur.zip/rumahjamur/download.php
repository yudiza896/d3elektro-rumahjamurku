<?php
include_once "koneksi.php";
if (isset($_GET['settingSuhu']))
	{
		$sql = "UPDATE setting SET suhu=".$_GET['settingSuhu']."";

		if (mysqli_query($koneksi, $sql)) {
		echo "data berhasil ditambahkan";
		}
		else {
			echo "gagal : ". mysqli_error($koneksi);
		}
	} else if (isset($_GET['settingKelembaban']))
	{
		$sql = "UPDATE setting SET kelembaban=".$_GET['settingKelembaban']."";

		if (mysqli_query($koneksi, $sql)) {
		echo "data berhasil ditambahkan";
		}
		else {
			echo "gagal : ". mysqli_error($koneksi);
		}
	}
	else {
		//echo "data";
		$sql = "SELECT * FROM setting LIMIT 1";

		$ambil=mysqli_query($koneksi, $sql);
		if ($ambil->num_rows > 0) {
	    while($row = $ambil->fetch_assoc()) {
	    	echo "#$";
	        echo $row["suhu"]."$".$row["kelembaban"]."$~";
	    }
		} else {
			echo mysqli_error($koneksi);
		}
	}