<?php
include_once "koneksi.php";
	$sql = "SELECT * FROM data ORDER BY id DESC LIMIT 1";

	$ambil=mysqli_query($koneksi, $sql);
	if ($ambil->num_rows > 0) {
	while($row = $ambil->fetch_assoc()) {
	    echo "[" .$row["suhu"].",".$row["kelembaban"]."]";
	}
	} else {
		echo mysqli_error($koneksi);
}