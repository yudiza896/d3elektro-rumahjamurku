<?php
include_once "koneksi.php";
if (isset($_GET['data']))
	{
		$data = explode('-',$_GET['data']);
		$panjang_data = count($data);

		echo "suhu : ".$data[0]."<br>";
		echo "kelembaban : ".$data[1]."<br>";
		
		//$tiket = uniqid();

		$sql = "INSERT INTO data (suhu, kelembaban) VALUES ('$data[0]','$data[1]')";

		if (mysqli_query($koneksi, $sql)) {
		echo "data berhasil ditambahkan";
		}
		else {
			echo "gagal : ". mysqli_error($koneksi);
		}
	}
