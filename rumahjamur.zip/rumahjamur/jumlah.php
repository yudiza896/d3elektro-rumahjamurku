<?php
include_once "koneksi.php";

$sql = "SELECT * FROM data WHERE DATE(waktu) = CURDATE()";

$ambil=mysqli_query($koneksi, $sql);
	if ($ambil->num_rows > 0) {
		echo mysqli_num_rows($ambil);
}
?>